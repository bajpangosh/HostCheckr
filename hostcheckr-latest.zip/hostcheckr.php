<?php
/**
 * Plugin Name: HostCheckr
 * Plugin URI: https://hostcheckr.kloudboy.com
 * Description: Instantly check if your hosting is slowing down your WordPress. Know Your Hosting. Instantly.
 * Version: 1.0.0
 * Author: Bajpan Gosh
 * Author URI: https://kloudboy.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: hostcheckr
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.8
 * Requires PHP: 7.4
 * 
 * 
 * HostCheckr - Know Your Hosting. Instantly.
 * Developed by Bajpan Gosh for KloudBoy
 * 
 * This plugin provides comprehensive WordPress hosting environment analysis,
 * system health monitoring, and performance optimization recommendations.
 * 
 * @package HostCheckr
 * @author Bajpan Gosh
 * @since 1.0.0
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Include plugin constants
require_once plugin_dir_path(__FILE__) . 'includes/constants.php';

// Include main class
require_once plugin_dir_path(__FILE__) . 'includes/class-hostcheckr.php';

// Activation and deactivation hooks
register_activation_hook(__FILE__, 'hostcheckr_activate');
register_deactivation_hook(__FILE__, 'hostcheckr_deactivate');

/**
 * Plugin activation function
 */
function hostcheckr_activate() {
    // Check minimum requirements
    if (version_compare(PHP_VERSION, '7.4', '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(esc_html__('HostCheckr requires PHP 7.4 or higher.', 'hostcheckr'));
    }
    
    if (version_compare(get_bloginfo('version'), '5.0', '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(esc_html__('HostCheckr requires WordPress 5.0 or higher.', 'hostcheckr'));
    }
    
    // Set default options if needed
    if (!get_option('hostcheckr_version')) {
        add_option('hostcheckr_version', HOSTCHECKR_VERSION);
    }
}

/**
 * Plugin deactivation function
 */
function hostcheckr_deactivate() {
    // Clean up if needed (but preserve user data)
    delete_transient('hostcheckr_system_info');
}

/**
 * Initialize the plugin
 */
function hostcheckr_init() {
    if (is_admin()) {
        new HostCheckr();
    }
}
add_action('plugins_loaded', 'hostcheckr_init');

/**
 * Add plugin action links
 */
function hostcheckr_plugin_action_links($links) {
    $action_links = array(
        'dashboard' => '<a href="' . admin_url('admin.php?page=hostcheckr') . '">' . __('Dashboard', 'hostcheckr') . '</a>',
        'support' => '<a href="https://hostcheckr.kloudboy.com/support" target="_blank">' . __('Support', 'hostcheckr') . '</a>',
    );
    return array_merge($action_links, $links);
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'hostcheckr_plugin_action_links');