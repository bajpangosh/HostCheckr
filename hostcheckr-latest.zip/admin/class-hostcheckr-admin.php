<?php
/**
 * Admin functionality for HostCheckr
 *
 * @package HostCheckr
 * @subpackage Admin
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin class for HostCheckr
 */
class HostCheckr_Admin {
    // Admin functionality will be organized here in future versions
}