<?php
/**
 * Plugin Constants
 *
 * @package HostCheckr
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
if (!defined('HOSTCHECKR_VERSION')) {
    define('HOSTCHECKR_VERSION', '1.0.0');
}

if (!defined('HOSTCHECKR_PLUGIN_FILE')) {
    define('HOSTCHECKR_PLUGIN_FILE', dirname(dirname(__FILE__)) . '/hostcheckr.php');
}

if (!defined('HOSTCHECKR_PLUGIN_URL')) {
    define('HOSTCHECKR_PLUGIN_URL', plugin_dir_url(HOSTCHECKR_PLUGIN_FILE));
}

if (!defined('HOSTCHECKR_PLUGIN_PATH')) {
    define('HOSTCHECKR_PLUGIN_PATH', plugin_dir_path(HOSTCHECKR_PLUGIN_FILE));
}